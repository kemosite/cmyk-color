ICC Profile Inspector version 2.4.0 ReadMe file
Last Update: February 22, 2009
------------------------------------------------------------------

ICC Profile Inspector is a free software to view ICC profiles under Microsoft 
Windows operating system (Windows 95 or later versions).  It displays the ICC 
header information, the ICC tag table, and data in each tag. It is a tool to 
aid checking ICC tag data. The tool is very useful for developing ICC tools 
and ICC profiles. It is aimed for checking tag data. Although it checks ICC 
profile's basic data structure, it was not designed to validate ICC profiles. 
The author accepts no liability for its behaviour.

System requirements:
  1) A PC runs under Windows 95 or later versions;
  2) Color monitor with at least 256 display colors;
  3) 10 Megabytes of free disk space.

Instalation:
  1) Download ICCProfileInspector.zip;
  2) Upzip the zip file;
  3) Double-click ICCProfileInspector.exe, the installer will guide you through 
     the rest of the installation procedures;
  4) If it prompts to install Microsoft vcredist_x86 package, please double-
     click vcredist_x86.exe under the unzip directory to install it before 
     running ICC Profile Inspector.

There are three methods to view an ICC profile:
1) a. Run ICC Profile Inspector (or double-click ICCViewer.exe); and 
   b. Click Browse... button in the dialog box and then select an ICC profile. 
2) a. Drop an ICC profile to the ICC Profile Inspector icon: have mouse point to 
      an ICC profile; push left-mouse down to select the ICC profile; 
   b. Move mouse pointer to the ICC Profile Inspector icon in the desktop while 
      the left-mouse is down; and 
   c. relief the mouse button. 
3) a. Have the mouse point to an ICC profile; 
   b. push right-mouse button down; 
   c. select the "Send To" section; and 
   d. select ICC Profile Inspector. 


Thank you for using ICC Profile Inspector! Any comments and suggestions 
are welcomed. please contact me via email ICCviewer@hotmail.com.

Huan (Huanzhao) Zeng